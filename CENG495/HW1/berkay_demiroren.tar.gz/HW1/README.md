# CENG495 - Homework1 - Activity Schedular

It is an leisure time activity schedular. It contains 5 different functionalities.

1 - User Inputted Activity : Clicking a cell twice make the cell editable
2 - API Supported Activities: 
    First, click the cell which make it highlighted. Then click one of the first three buttons.
    a - GameAPI 🎮: Controller icon will bring a random video game to play.
    b - MovieAPI 🍿: Filmstrip icon will bring a random movie to watch.
    c - BoredAPI 📅: Calendar icon will bring a random event to perform or attend.

To export the table as PNG please click the printer icon it will direct you.


## Design choices:

I've used Django for backend and HTML,CSS and JS (Jquery,AJAX,Vanilla) for the browser side operations.
The reason why I've picked those, I had a little experience wtih those and they are easy to implement.

URL : https://arcane-caverns-69909.herokuapp.com/ 

Before clicking the link please send an email.I will immediately respond. :)
email : berkay.demiroren@metu.edu.tr

Berkay Demirören 2309888
