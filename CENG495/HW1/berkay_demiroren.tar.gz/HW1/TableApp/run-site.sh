#!/usr/bin/env bash
git add .
git commit -m "Applied changes running app"
git push heroku main
heroku open
