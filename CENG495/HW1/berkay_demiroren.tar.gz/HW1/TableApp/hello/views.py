from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpRequest
import requests
from django.views.decorators.csrf import csrf_exempt
import base64
from urllib.parse import unquote


# Create your views here.
def index(request):
    return render(request, "index.html")

@csrf_exempt 
def exportTable(request):
    post_data = {
        'key': '2255dfd1c793e072138bcb4b5571fcf3',
        'image': parse_body(request)
    }
    response = requests.post('https://api.imgbb.com/1/upload', data=post_data)
    print(response.text)
    
    return HttpResponse(response.text,content_type='application/json')

def parse_body(request) -> str:
    decoded =  unquote(unquote(str(request.body)))
    parsed= str(decoded).split(',')[1][:-1]
    print(parsed)
    return parsed
