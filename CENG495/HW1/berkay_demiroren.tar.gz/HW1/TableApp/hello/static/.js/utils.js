function updateVal(currentEle, value)
{
    $(currentEle).html('<input class="thVal" type="text" value="'+value+'" />');
    $(".thVal").focus();
    $(".thVal").keyup(function(event){
        if(event.keyCode == 13){
            $(currentEle).html($(".thVal").val().trim());
        }
    });

    $('body').not(".thVal").click(function(){
        if(('.thVal').length != 0)
        {
            $(currentEle).html($(".thVal").val().trim());
        }
    });
}
function createGameActivity(name){
    return `Play ${name}`;
}
function createMovieActivity(activity){
    return `Watch ${activity}`
}
function generateRandomGameId(){
    return Math.floor(Math.random()*1000);
}
function putEventFromGameApiCallback (response) {
    let activity = createGameActivity(response.results[0].name);
    addEventToCell(activity);
}
function addEventToCell(event){
    $(`#${cellId}`).html(event)
}

function setClickedCellId(id){
    let currentCell = document.getElementById(id)
    let prevCell = document.getElementById(cellId)

    if(currentCell.style.border == blueBorder){
        currentCell.style.border = plainBorder
    }
    else{
        prevCell.style.border = plainBorder;
        currentCell.style.border = blueBorder;
    }
    cellId = id
}
function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

function parsePrintResponse(response){
    return response.data.url;
}

function showLinkAsPopUp(url){
    if (window.confirm('Press OK to display image.')) {
        window.open(url, '_blank').focus();
    }
}
function cleanBorder(){
    document.getElementById(cellId).style.border = '2px solid black';
}
