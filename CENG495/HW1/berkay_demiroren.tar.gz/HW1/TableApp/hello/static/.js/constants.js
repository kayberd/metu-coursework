const BORED_API = {
    ENDPOINT:'https://www.boredapi.com/api/activity/',
};

const MOVIE_API = {
    ENDPOINT:'https://k2maan-moviehut.herokuapp.com/api/random'
}

const GAME_API = {
    ENDPOINT:`https://www.giantbomb.com/api/games/?api_key=290fa17c6bf879d65395a0547292135510d1a2f1&format=jsonp&json_callback=putEventFromGameApiCallback&limit=1&field_list=name&offset=`,
    API_KEY:'290fa17c6bf879d65395a0547292135510d1a2f1',
}

const ROW_COUNT = 9
const COLUMN_COUNT = 7

var randomId = 1;
var cellId = "0-0";
let blueBorder = '3px solid blue';
let plainBorder = '2px solid black';