
function putEventFromBoredApi(){
    $.getJSON(`${BORED_API.ENDPOINT}`,(response) => {
        addEventToCell(response.activity);
    })
}
function putEventFromMovieApi() {
    $.getJSON(`${MOVIE_API.ENDPOINT}`,(response) => {
        let activity = createMovieActivity(response.name);
        console.log(activity);
        addEventToCell(activity);
    })
}
function putEventFromGameApi(){
    randomId = generateRandomGameId();
    console.log(GAME_API.ENDPOINT+randomId)
    $.ajax({
        type: "GET",
        url:  GAME_API.ENDPOINT+randomId,
        dataType:"jsonp",
        async: false,
    });
}
function makeAllCellsEditable(){
    $("td").dblclick(function(e){
        e.stopPropagation();   
        var currentEle = $(this);
        var value = $(this).html();
        updateVal(currentEle, value);
      });
  
}
function addClickListenerToCells(){
    $('tbody').bind('click', (e)=>{
        setClickedCellId(e.target.id);
      });
}
function exportTable(){
    $.ajaxSetup({beforeSend: function(xhr, settings) {
        xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
        }});
    var img   = document.getElementById("table");
    html2canvas(img).then (
        function(canvas) {
            console.log(canvas.toDataURL());
            $.ajax({
                type: "POST",
                url: "/print",
                data: {
                    imgBase64: canvas.toDataURL()
                }
            }).done(
                function(e) {
                    showLinkAsPopUp(parsePrintResponse(e));
                }
            );
        }
    )
}
function onInit() {
    makeAllCellsEditable();
    addClickListenerToCells();
}

